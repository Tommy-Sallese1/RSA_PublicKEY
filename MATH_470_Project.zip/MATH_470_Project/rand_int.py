import random

a = int(4)
b = int(3)
c = a%b
print(c)
