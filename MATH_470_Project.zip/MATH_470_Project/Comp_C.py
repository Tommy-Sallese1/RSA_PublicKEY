import math
import random
from Primes import primes
from ComputeGCD import computeGCD

#Randomly generate two primes that are 3 or 4 digits
A = True
p = int(0)
q = int(0)
C = int(0)
m_num = int(0)
d = int(0)
p_prime = int(0)
q_prime = int(0)
N_prime = int(0)
j = 0
G = int(0)



p = int(7)
q = int(19)
e = int(5)
N = int(133)
N_prime = int(108)
d = int(65)
A = True
m = "this is the plaintext"
m = m.replace(" ","")
list2 = []
list3 = []
list4 = []
for letter in m:
    print(letter)
    Z = ord(letter)
    list3.append(Z)
    c = (ord(letter)**e)%N
    print(c)
    list2.append(c)

#element in list 2 are ciphertext
print(list2)

#Decrypt ciphertext

for element in list2:
    print(element)
    G = ((element**d)%N)
    list4.append(G)


print("this is list 3",list3)
print("list 4",list4)
