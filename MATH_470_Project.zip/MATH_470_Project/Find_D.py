p = int(1301)
q = int(1567)
e = int(103)
N_prime = int(2035800)
d = int(0)
A = True
while A == True:
    if (((e*d)-1)%N_prime)==0:
        print(d)
        A = False
    elif d == N_prime:
        print("there is no inverse")
        A = False
    else:
        A = True
        d += 1

# this gave the right answer   for 3.7